//
//  SettingsViewController.swift
//  Health
//
//  Created by Ziga Porenta on 21/10/2021.
//

import UIKit


class SettingsViewController: UIViewController {
    
    @IBOutlet private var readingsTextField: UITextField!
    @IBOutlet private var lagTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        readingsTextField.delegate = self
        lagTextField.delegate = self
        readingsTextField.text = String(UserSettings.shared.numberOfReadings)
        lagTextField.text = String(UserSettings.shared.lag)
    }
    
    @IBAction private func doneAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}

extension SettingsViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        UserSettings.shared.numberOfReadings = Int(readingsTextField.text ?? "0") ?? 0
        UserSettings.shared.lag = Int(lagTextField.text ?? "0") ?? 0
    }
}
