//
//  ViewController.swift
//  Health
//
//  Created by iMac on 19/04/21.
//

import UIKit
import HealthKit
import WatchConnectivity


struct Sample {
    let step: Double
    let date: Date
}

class ViewController: UIViewController {
    
    @IBOutlet private var lblHeartRate: UILabel!
    @IBOutlet private var lblHeartRateVariation: UILabel!
    @IBOutlet private var txtBreath: UITextField!
    private var healthStore = HKHealthStore()
    
    /// Keeps track of the heart rate session state
    private var hrState: HRSessionState = .ready {
        didSet {
            DispatchQueue.main.async {
                self.setHRButtonLabel()
            }
        }
    }
    
   
    @IBOutlet private var heartRateButton: UIButton!
    
    // MARK: -

    override func viewDidLoad() {
        super.viewDidLoad()

        autorizeHealthKit()
        HRService.shared.delegate = self 

        setHRButtonLabel()
        
    }
    
    func autorizeHealthKit() {
        let healthKitTypes: Set = [
            HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!,
            HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRateVariabilitySDNN)!,
            HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.respiratoryRate)!
        ]
        
        healthStore.requestAuthorization(toShare: healthKitTypes, read: healthKitTypes) { (isSuccess, error) in
            
            if isSuccess {
                print(isSuccess)
            } else {
                self.showAlert(message: "Could not authorise health kit")
                print(error as Any)
            }
        }
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        AppUtility.lockOrientation(.portrait)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Don't forget to reset when view is being removed
        AppUtility.lockOrientation(.all)
    }
    
    // MARK: Heart rate
    
    @IBAction func btnHeartRateClick(_ sender: UIButton) {
        
        switch hrState {
        case .running:
            stopHRSessionOnAppleWatch()
        case .ready:
            startHRSessionOnAppleWatch()
        }
    }
    
    private func setHRButtonLabel() {
        
        let title: String
        switch hrState {
        case .running:
            title = "Stop HR measurement"
        case .ready:
            title = "Start HR measurement"
        }
    
        self.heartRateButton.setTitle(title, for: .normal)
               
    }
    
    private func startHRSessionOnAppleWatch() {
        
        guard WCSession.isSupported(), WCSession.default.activationState == .activated else {
            showAlert(message: "Watch connectivity session not active")
            return
        }
        
        guard iOSSyncManager.shared.isWatchAppInstalled == true else {
            showAlert(message: "Companion watch app not installed")
            return
        }
        
        let config = HKWorkoutConfiguration()
        config.activityType = .mindAndBody
        config.locationType = .indoor
        
        healthStore.startWatchApp(with: config) { [weak self] success, error in
            
            if success {
                self?.hrState = .running
            } else {
                self?.showAlert(message: "Could not start workout session")
            }
        }
    }
    
    // MARK: -
    
    func getHeartVariability() {
        guard let sampleData = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRateVariabilitySDNN) else {
            return
        }
        let sortDescription = NSSortDescriptor(key: HKPredicateKeyPathStartDate, ascending: false)
        let query = HKSampleQuery(sampleType: sampleData, predicate: nil, limit: Int(HKObjectQueryNoLimit), sortDescriptors: [sortDescription]) { (query, sample, error) in
            
            guard let data = sample?.first as? HKQuantitySample else {
                print("No data to display")
                return
            }
            
            DispatchQueue.main.async {
                self.lblHeartRateVariation.text = "Heart Rate Variability : \(Int(data.quantity.doubleValue(for: HKUnit(from: "ms"))))"
            }
        }
        healthStore.execute(query)
    }
    
    
    func saveHeight(value: Double) {
        if let type = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.respiratoryRate) {
            let date = Date()
            let quantity = HKQuantity(unit: HKUnit(from: "count/min"), doubleValue: value)
            let sample = HKQuantitySample(type: type, quantity: quantity, start: date, end: date)
            self.healthStore.save(sample, withCompletion: { (success, error) in
                print("Saved \(success), error \(String(describing: error))")
                if success {
                    DispatchQueue.main.async {
                        self.txtBreath.text = ""
                    }
                }
            })
        }
    }
    
    
    @IBAction func btnHeartRateVariationClick(_ sender: UIButton) {
        // TODO:
        self.getHeartVariability()
    }
    
    @IBAction func btnBreathClick(_ sender: UIButton) {
        // TODO:
        if let cost = Double(txtBreath.text!) {
            self.saveHeight(value: cost)
        }
    }
    
    private func stopHRSessionOnAppleWatch() {
        // Reset the text
        lblHeartRate.text = "Heart rate"
        
        // Send a message to the watch
        iOSSyncManager.shared.stopSession()
    }
    
}

extension ViewController: HRServiceDelegate {
        
    func hrWasUpdated(hr: String) {
        if hrState == .running {
            lblHeartRate.text = hr
        }
    }
    
    func sessionStoppedOnWatch() {
        hrState = .ready
        self.lblHeartRate.text = "Heart rate"
    
    }
    
    
    func shouldEndSession() {
        stopHRSessionOnAppleWatch()
    }
}

extension ViewController {

    func showAlert(message: String) {
        
        let alert = UIAlertController(title: "HealthApp", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
        
    }
    
}
