//
//  BreathAnalyzer.swift
//  Health
//
//  Created by Asfand Hafeez on 07/03/2023.
//
import AVFoundation
import Accelerate
import CoreMotion
protocol BreathRate {
    func breathRate(rate:Double)
    
        
    
}

class BreathRateAnalyzer: NSObject, AVCaptureAudioDataOutputSampleBufferDelegate {
    private let session = AVCaptureSession()
    private let output = AVCaptureAudioDataOutput()
    private var breathRate: Double?
    var delegate :BreathRate?
    override init() {
        super.init()
        
        // Set up capture session
        if let device = AVCaptureDevice.default(for: .audio) {
            let input = try! AVCaptureDeviceInput(device: device)
            session.addInput(input)
            output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "audio"))
            session.addOutput(output)
            let connection = output.connection(with: .audio)!
            connection.preferredVideoStabilizationMode = .off
          
        }
        
       
        
    }
    func startRecord()   {
        DispatchQueue.main.async {
            
            // Start capture session
            self.session.startRunning()
        }
    }
    
    func stopRecord()   {
        DispatchQueue.main.async {
            
            // Start capture session
            self.session.stopRunning()
        }
    }
    
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Calculate breath rate from audio sample buffer
        if let rate = calculateBreathRate(from: sampleBuffer) {
            breathRate = rate
            delegate?.breathRate(rate: rate)
            print("Breath rate: \(breathRate!)")
        }else {
            print("Breath rate nil ")
        }
    }
    
    private func calculateBreathRate(from sampleBuffer: CMSampleBuffer) -> Double? {
        // Extract audio data from sample buffer
        guard let blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) else {
            return nil
        }
        var audioBufferList = AudioBufferList(
            mNumberBuffers: 1,
            mBuffers: AudioBuffer(
                mNumberChannels: 1,
                mDataByteSize: 0,
                mData: nil
            )
        )
        CMBlockBufferCopyDataBytes(
            blockBuffer,
            atOffset: 0,
            dataLength: 0,
            destination: &audioBufferList.mBuffers.mDataByteSize
        )
        audioBufferList.mBuffers.mData = UnsafeMutableRawPointer.allocate(
            byteCount: Int(audioBufferList.mBuffers.mDataByteSize),
            alignment: 0
        )
        
        guard let decloc = audioBufferList.mBuffers.mData?.deallocate() else {return nil }
        guard let mData = audioBufferList.mBuffers.mData else {return nil }
        defer { decloc }
        CMBlockBufferCopyDataBytes(
            blockBuffer,
            atOffset: 0,
            dataLength: Int(audioBufferList.mBuffers.mDataByteSize),
            destination: mData
        )

        // Get audio format and sample rate
        let audioFormat = CMSampleBufferGetFormatDescription(sampleBuffer).flatMap {
            CMAudioFormatDescriptionGetStreamBasicDescription($0)?.pointee
        }
        let sampleRate = audioFormat?.mSampleRate ?? 44100

        // Analyze audio data to determine breath rate
        let sampleCount = audioBufferList.mBuffers.mDataByteSize / UInt32(audioFormat!.mBytesPerFrame)
        var breathCount = 0
        for i in 0..<Int(sampleCount) {
            let byteOffset = i * Int(audioFormat!.mBytesPerFrame)
            let data = audioBufferList.mBuffers.mData!.load(fromByteOffset: byteOffset, as: Float32.self)
            if data >= 0.05 { // adjust this threshold as necessary
                breathCount += 1
            }
        }
        let breathRate = Double(breathCount) / (Double(sampleCount) / Double(sampleRate)) * 60.0
        print("breathRate \(breathRate)")
        return !breathRate.isFinite ? nil : breathRate
    }
}
