//
//  MainVC.swift
//  Health
//
//  Created by Asfand Hafeez on 02/03/2023.
//

import UIKit

class MainVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
    }
    
    
    @IBAction func hrTrackingBtn()  {
        
        let storyBoard = UIStoryboard(name: "HRTracking", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewController")
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    

    
    @IBAction func inFinityTrackingBtn()  {
        
        
        
        
        actionSheet()
        
    }
    
    @IBAction func accelerometerGameBtn(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "AccelerometerGame", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AccelerometerGame") as! AccelerometerGame
        vc.trackTYpe = .directHeart
        vc.isHeart = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func actionSheet()  {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Microphone", style: .default , handler:{ (UIAlertAction)in
            let storyBoard = UIStoryboard(name: "InitifinityTracking", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "InfinityTrackingVC") as! InfinityTrackingVC
            vc.trackTYpe = .micor
            self.navigationController?.pushViewController(vc, animated: true)
        }))
        
        alert.addAction(UIAlertAction(title: "Heart rate", style: .default , handler:{ (UIAlertAction)in
            let storyBoard = UIStoryboard(name: "InitifinityTracking", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "InfinityTrackingVC") as! InfinityTrackingVC
            vc.trackTYpe = .heart
            vc.isHeart = true
            self.navigationController?.pushViewController(vc, animated: true)
        }))
        
        alert.addAction(UIAlertAction(title: "Breath rate", style: .default , handler:{ (UIAlertAction)in
            let storyBoard = UIStoryboard(name: "InitifinityTracking", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "InfinityTrackingVC") as! InfinityTrackingVC
            vc.trackTYpe = .breath
            self.navigationController?.pushViewController(vc, animated: true)
        }))
        alert.addAction(UIAlertAction(title: "Direct Heart Rate", style: .default , handler:{ (UIAlertAction)in
            let storyBoard = UIStoryboard(name: "InitifinityTracking", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "InfinityTrackingVC") as! InfinityTrackingVC
            vc.trackTYpe = .directHeart
            vc.isHeart = true
            self.navigationController?.pushViewController(vc, animated: true)
        }))
        
        alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler:{ (UIAlertAction)in
            
        }))
        
        
        //uncomment for iPad Support
        alert.popoverPresentationController?.sourceView = self.view
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
}
enum TrackType {
    case micor
    case heart
    case breath
    case directHeart
}
