//
//  HRService.swift
//  Health
//
//  Created by Ziga Porenta on 21/10/2021.
//

import Foundation

protocol HRServiceDelegate: AnyObject {
    /// Sends the current heart rate
    func hrWasUpdated(hr: String)
    
    /// Notifies the delegate the session should end
    func shouldEndSession()
    
    /// Notifies the delegate the session was stopped on the watch 
    func sessionStoppedOnWatch()
}

class HRService {
    
    static let shared = HRService()
    
    weak var delegate: HRServiceDelegate?
    
    private var currentHRString: String = "-"
    
    private var state: HRSessionState = .ready
    
    // Heart rate session settiongs
    private var readingsLeft: Int?
    private var lagInSeconds: Int?
    private var dateOfLastHR: Date?
    
    
    func updateWith(heartRate: Int?) {
        
        // Check for hr
        guard let hr = heartRate, hr != 0 else { return }
    
        // Check if we should lag the hr reading
        if let lag = lagInSeconds, let date = dateOfLastHR {
            
            /// Check if we can send a new one
            guard date.addingTimeInterval(TimeInterval(lag)) < Date() else {
                print("ℹ️ NOT UPDATING - LAG")
                return
            }
        }
        
        self.dateOfLastHR = Date()
        processHR(hr)
    }
    
    
    func sessionWasStarted() {
        reset()
    }
    
    private func processHR(_ hr: Int) {
        
        // Check if we have limited readings
        if let readingsLeft = readingsLeft {
            // If there are no more readings stop the session
            if readingsLeft < 0 {
                state = .ready
                DispatchQueue.main.async {
                    self.delegate?.shouldEndSession()
                }
                print("ℹ️ END THE SESSION ")
                return
            } else {
                print("ℹ️ READINGS LEFT \(self.readingsLeft!)")
                self.readingsLeft! -= 1
            }
        }
 
        // Update the delegate
        DispatchQueue.main.async {
            self.currentHRString = hr != 0 ? String(hr) : "--"
            self.delegate?.hrWasUpdated(hr: self.currentHRString)
        }
    }
    
    private func reset() {
        
        print("ℹ️ RESETING THE SESSION")
        readingsLeft = nil
        lagInSeconds = nil
        
        if UserSettings.shared.numberOfReadings != 0 {
            readingsLeft = UserSettings.shared.numberOfReadings
        }
        
        if UserSettings.shared.lag != 0 {
            lagInSeconds = UserSettings.shared.lag
        }
    }
    
}

