//
//  UserSettings.swift
//  Health
//
//  Created by Ziga Porenta on 21/10/2021.
//

import Foundation

class UserSettings {
    
    static let shared = UserSettings()
    
    private static let defaults = UserDefaults()
    
    var numberOfReadings: Int {
        get { loadFromDefaults(key: .numberOfReadings) ?? 0 }
        set { saveToDefaults(key: .numberOfReadings, object: newValue)}
    }
    
    var lag: Int {
        get { loadFromDefaults(key: .lag) ?? 0 }
        set { saveToDefaults(key: .lag, object: newValue)}
    }
    
    // MARK: - Helpers
    
    private func loadFromDefaults<T>(key: UserSettings.Keys) -> T? {
        return UserSettings.defaults.object(forKey: key.rawValue) as? T
    }
    
    private func saveToDefaults(key: UserSettings.Keys, object: Any) {
        UserSettings.defaults.set(object, forKey: key.rawValue)
    }
    
}

extension UserSettings {
    
    enum Keys: String {
        
        case numberOfReadings
        case lag
  
    }
    
}

    
    

