//
//  iOSSyncManager.swift
//  Health
//
//  Created by Ziga Porenta on 21/10/2021.
//

import Foundation
import WatchConnectivity


class iOSSyncManager: NSObject, WCSessionDelegate {
        
    static let shared = iOSSyncManager()
    
    var session: WCSession? = nil
    
    var activeSession: Bool = false
    
    var isWatchAppInstalled: Bool? {
        session?.isWatchAppInstalled
    }
   
    var isWatchPaired: Bool? {
        session?.isPaired
    }
    
    override private init() {
        super.init()
    }
    
    func setup() {
        if WCSession.isSupported() {
            session = WCSession.default
            session?.delegate = self
            session?.activate()
        }
    }
    
    
    func stopSession() {
        session?.sendMessage([SyncConstants.stopSession.rawValue: "true"], replyHandler: nil, errorHandler: { error in
            print(error)
        })
    }
    

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
       
        print(" 📱 \(message)")
        
        // Heart rate data
        if let hr = message[SyncConstants.hr.rawValue] as? Int {
            HRService.shared.updateWith(heartRate: hr)
        }
        
        // Session started
        if let _ = message[SyncConstants.sessionStarted.rawValue] {
            HRService.shared.sessionWasStarted()
        }
        
        // Stop session 
        if let _ = message[SyncConstants.stopSession.rawValue] {
            DispatchQueue.main.async {
                HRService.shared.delegate?.sessionStoppedOnWatch()
            }
        }
    }
    
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any]) {
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print(" 📱 Activated ")
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) { }
    func sessionDidDeactivate(_ session: WCSession) { }

}


