//
//  SyncConstants.swift
//  Health
//
//  Created by Ziga Porenta on 20/10/2021.
//

import Foundation

enum SyncConstants: String {
    
    case hr
    case sessionStarted
    case stopSession
    case activeSession

}
