//
//  HRSessionState.swift
//  Health
//
//  Created by Ziga Porenta on 21/10/2021.
//

import Foundation

enum HRSessionState {
    case running
    case ready
}
