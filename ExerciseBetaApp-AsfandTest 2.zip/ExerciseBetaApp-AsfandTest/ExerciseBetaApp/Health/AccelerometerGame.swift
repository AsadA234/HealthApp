//
//  InfinityTrackingVC.swift
//  Health
//
//  Created by Asfand Hafeez on 02/03/2023.
//

import UIKit
import AVFoundation
import Accelerate
import HealthKit
//import Foundation
import WatchConnectivity
import SwiftUI
import CoreMotion



class AccelerometerGame: UIViewController,AVCaptureAudioDataOutputSampleBufferDelegate , UITextFieldDelegate{
    
    var second = 0
    var averageValues = Int()
    
    // carddetails model varaibles
    var UserCardDetails   = [GetCardDetails]();
    @IBOutlet weak var ralteLbl1: UILabel!
    @IBOutlet weak var ralteLbl3: UILabel!
    @IBOutlet weak var ralteLbl2: UILabel!
    let healthStore = HKHealthStore()
    var heartRateQuery: HKQuery?
    var heartRateObserver: HKObserverQuery?
    @IBOutlet weak var totalLbl2: UILabel!
    @IBOutlet weak var totalLbl: UILabel!
    @IBOutlet weak var rateLbl: UILabel!
    @IBOutlet weak var playBtn: UIButton!
    
    
    
    @IBOutlet weak var Speedtxtfield: UITextField!
    @IBOutlet weak var timePeriod: UITextField!
    @IBOutlet weak var hideSVInnerVw: UIView!
    @IBOutlet weak var hideSV: UIStackView!
    
    @IBOutlet weak var greyBall: UIImageView!
    @IBOutlet weak var blackCircle: UIView!
    
    var scoreLabelValue: Int = 0
    
    let motionManager = CMMotionManager()
    var gameTimer: Timer?
    
    var isHeart = false
    var myValue: Int = 1
    let brFromMic = BreathRateAnalyzer()
    var isPlay = false
    var trackTYpe  = TrackType.micor
    var isAnimationRunning = true
    var updateHeartRateLoopValue = 0
    var animationForHEartRate = true
    
    var totalHeartRateValue = 0
    var totalHeartRateValueCount = 0
    var totalPeriodValue = 1
    var averageValue = 0
    
    
    
    private var hrState: HRSessionState = .ready {
        didSet {
            DispatchQueue.main.async {
                self.setHRButtonLabel()
            }
        }
    }
    var hrValues = [Int]()
    var avValues = [Int]()
    var  timer = Timer()
    var timetaken = Float()
    var i = 0
    var timers : Timer?
    @IBOutlet weak var breathRateLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        hrValues =  [75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52, 75, 74, 73, 50, 51, 52, 54, 88, 89, 90, 110, 120, 130, 50, 51, 52]
        timePeriod.text = "3"
        Speedtxtfield.text = "1"
        HRService.shared.delegate = self
        
        
        Speedtxtfield.delegate = self
        timePeriod.delegate = self
        
        if isHeart {
            rateLbl.text = "Heart Rate:"
            totalLbl.text = "Average Rate:"
            totalLbl2.text = "Total Exhales:"
        //    hideSV.isHidden = true
            hideSVInnerVw.isHidden = true
            hideSV.isHidden = false
            totalLbl2.isHidden = false
            totalLbl2.textColor = .clear
        }else {
            rateLbl.text = "Breath Rate:"
            totalLbl.text = "Total Inhales:"
            totalLbl2.text = "Total Exhales:"
            rateLbl.text = "Breath Rate:"
          //  hideSV.isHidden = false
            hideSVInnerVw.isHidden = false
            totalLbl2.isHidden = false
            totalLbl2.textColor = .label
    
        }
        authorizeHealthKit()
//               hrValues = [50,55,65,75,85,95,105]
//               updateAnimation(rate: hrValues[1])
        
        blackCircle.isHidden = true
        motionManager.startAccelerometerUpdates()
        blackCircle.clipsToBounds = true
        blackCircle.layer.cornerRadius = 30
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        AppUtility.lockOrientation(.landscape)
        
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case Speedtxtfield:
            if textField.text!.isEmpty{
                Speedtxtfield.text = "1"
            }
        case timePeriod:
            if textField.text!.isEmpty{
                timePeriod.text = "3"
            }
        default:
            print("Nothing")
        }
    }
    
    
    
    private func setHRButtonLabel() {
        
        switch hrState {
        case .running:
            
            playBtn.setImage(UIImage(systemName: "stop.circle.fill"), for: .normal)
        case .ready:
            playBtn.setImage(UIImage(systemName: "play.square"), for: .normal)
        }
    }
    
    private func startHRSessionOnAppleWatch() {
        
        guard WCSession.isSupported(), WCSession.default.activationState == .activated else {
            stopPlayBtn()
            showAlert(message: "Watch connectivity session not active")
            return
        }
        
        guard iOSSyncManager.shared.isWatchAppInstalled == true else {
            stopPlayBtn()
            showAlert(message: "Companion watch app not installed")
            return
        }
        
        let config = HKWorkoutConfiguration()
        config.activityType = .mindAndBody
        config.locationType = .indoor
        
        healthStore.startWatchApp(with: config) { [weak self] success, error in
            
            if success {
                self?.hrState = .running
            } else {
                self?.showAlert(message: "Could not start workout session")
                self?.stopPlayBtn()
            }
        }
    }
    
    func stopPlayBtn()  {
        self.playBtn.setImage(UIImage(systemName: "play.square"), for: .normal)
        self.isPlay = false
    }
    // MARK: -
    
    func getHeartVariability() {
        guard let sampleData = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRateVariabilitySDNN) else {
            return
        }
        let sortDescription = NSSortDescriptor(key: HKPredicateKeyPathStartDate, ascending: false)
        let query = HKSampleQuery(sampleType: sampleData, predicate: nil, limit: Int(HKObjectQueryNoLimit), sortDescriptors: [sortDescription]) { (query, sample, error) in
            
            guard let data = sample?.first as? HKQuantitySample else {
                print("No data to display")
                return
            }
            
            DispatchQueue.main.async {
                self.ralteLbl2.text = "\(Int(data.quantity.doubleValue(for: HKUnit(from: "ms"))))"
            }
        }
        healthStore.execute(query)
    }
    
    
    func saveHeight(value: Double) {
        if let type = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.respiratoryRate) {
            let date = Date()
            let quantity = HKQuantity(unit: HKUnit(from: "count/min"), doubleValue: value)
            let sample = HKQuantitySample(type: type, quantity: quantity, start: date, end: date)
            self.healthStore.save(sample, withCompletion: { (success, error) in
                print("Saved \(success), error \(String(describing: error))")
                if success {
                    DispatchQueue.main.async {
                        self.ralteLbl1.text = ""
                    }
                }
            })
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    func authorizeHealthKit() {
        let healthKitTypes: Set<HKObjectType> = [HKObjectType.quantityType(forIdentifier: .heartRate)!]
        healthStore.requestAuthorization(toShare: nil, read: healthKitTypes) { (success, error) in
            if !success {
                print("Error requesting authorization for heart rate data: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
    
    
    
    func checkRecordPermission() {
        switch AVAudioSession.sharedInstance().recordPermission {
        case .granted:
            print("granted")
        case .denied:
            print("denied")
        case .undetermined:
            print("Request permission here")
        @unknown default:
            print("Unknown case")
        }
    }
        
    
    func startHeartRateQuery(isBreath:Bool) {
        let heartRateType = HKObjectType.quantityType(forIdentifier: isBreath ? .respiratoryRate : .heartRate)!
        let heartRateQuery = HKSampleQuery(sampleType: heartRateType, predicate: nil, limit: 1, sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)]) { [weak self] (query, samples, error) in
            guard let self = self else {
                return
                
            }
            if let sample = samples?.first as? HKQuantitySample {
                let heartRateUnit = HKUnit(from: "count/min")
                let heartRate = sample.quantity.doubleValue(for: heartRateUnit)
                DispatchQueue.main.async {
                    //                    self.heartRateLabel.text = "\(Int(heartRate)) bpm"
                    print(heartRate)
                    
                }
            }
            else {
                print("No heart rate data available: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        
//
//        guard let url = Bundle.main.url(forResource: "Infinity01", withExtension: "json")else{return}
//        guard let data = try? Data(contentsOf: url)else{return}
//        guard let json = try? JSONSerialization.jsonObject(with: data,options:[]) as? [String:Any]else{return}
//      print(json)
//
//
//    //    healthStore.execute(heartRateQuery)
//       // healthStore.execute(json  as! HKQuery)
//
////        if let query = HKQuery.from(json:json){
////            healthStore.execute(query)
////        }
//        if let query = HKQuery.from(json: json){
//            healthStore.execute(query)
//        }
        
        print(heartRateQuery)
        
        guard let url = Bundle.main.url(forResource: "Infinity01", withExtension: "json") else {
           return
       }
       guard let data = try? Data(contentsOf: url) else {
           return
       }
       guard let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] else {
           return
       }
       print(json)

       if let type = json["type"] as? String, type == "heart_rate" {
           let sampleType = HKSampleType.quantityType(forIdentifier: .heartRate)!
           let predicate = HKQuery.predicateForSamples(withStart: Date.distantPast, end: Date(), options: [])
           let query = HKSampleQuery(sampleType: sampleType, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { (query, samples, error) in
               if let samples = samples as? [HKQuantitySample] {
                   for sample in samples {
                       let heartRate = sample.quantity.doubleValue(for: HKUnit.count().unitDivided(by: HKUnit.minute()))
                       let date = sample.startDate
                       print("Heart rate: \(heartRate) at \(date)")
                   }
               }
           }
           healthStore.execute(query)
       } else {
           // Handle error
       }

        
        heartRateObserver = HKObserverQuery(sampleType: heartRateType, predicate: nil) { [weak self] (query, completionHandler, error) in
            guard let self = self else { return }
            if let error = error {
                print("Error observing heart rate data changes: \(error.localizedDescription)")
            } else {
                
                //                self.healthStore.execute(heartRateQuery)
            }
        }
        healthStore.execute(heartRateObserver!)
    }

    
    
    @IBAction func playBtnTapped() {
//        if timePeriod.text?.isEmpty ?? true || timePeriod.text == nil{
//            AlertControl.shared.showOnlyAlert("Health", message: "Kindly Enter Time Period")
//        }
//        else{
            // totalPeriodValue = Int(timePeriod.text!)!
            if isPlay {
                playBtn.setImage(UIImage(systemName: "play.square"), for: .normal)
                isPlay = false
                
                blackCircle.isHidden = false
                blackCircle.frame.origin = randomPoint(for: blackCircle.frame.size)
                gameTimer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true, block: { [weak self] timer in
                    guard let self = self,
                          let accelerometerData = self.motionManager.accelerometerData else {
                        return
                    }
                    self.move(ball: self.greyBall, with: accelerometerData)
                    if self.greyBall.frame.intersects(self.blackCircle.frame) {
                        print("Grey ball is inside black circle")
                       
                        self.blackCircle.frame.origin = self.randomPoint(for: self.blackCircle.frame.size)
                        self.scoreLabelValue = self.scoreLabelValue + 200
                        self.ralteLbl3.text = "\(self.scoreLabelValue)"
//                                    print(self.scoreLabelValue)
                    }
                })
                
                //                switch trackTYpe {
                //                case .heart:
                //                    updateHeartRateLoopValue = 0
                //                    totalHeartRateValue = 0
                //                    totalHeartRateValueCount = 0
                //                    averageValue = 0
                //                    self.ralteLbl1.text = "0"
                //                    self.ralteLbl3.text = "0"
                //                    self.animationForHEartRate = true
                //                case .breath:
                //                    // Stop breath tracking
                //                    break
                //                default:
                //                    break
                //                }
                
            }else {
                playBtn.setImage(UIImage(systemName: "stop.circle.fill"), for: .normal)
                isPlay = true
                gameTimer?.invalidate()
                blackCircle.isHidden = true
                //                switch trackTYpe {
                //                case .heart:
                //                    startHeartRateQuery(isBreath: false)
                //               //     hrValues = [50,55,65,75,85,95,105]
                //
                //                    self.totalHeartRateValue = self.hrValues[self.updateHeartRateLoopValue] + self.totalHeartRateValue
                //                    self.averageValue = self.totalHeartRateValue/(self.updateHeartRateLoopValue+1)
                //
                //                    self.ralteLbl1.text = self.hrValues[self.updateHeartRateLoopValue].description
                //                    self.ralteLbl3.text = self.averageValue.description
                //
                //
                //                    if Speedtxtfield.text!.isEmpty || Speedtxtfield.text == nil{
                //
                //                    }
                //                    else{
                //                        myValue = Int(Speedtxtfield.text!)!
                //                    }
                //
                //                    //         animationView.animationSpeed = CGFloat(myValue)
                //                    // this is add code / *
                //                    let radius: CGFloat = 50.0
                //                    let speed: CGFloat = CGFloat(myValue) // myValue is the speed value entered by the user
                //                    let circumference = 2 * CGFloat.pi * radius
                //                    let distance = circumference
                //                    let timetaken = Float(distance / speed)
                //
                //                    print("Distance: \(distance) points")
                //                    print("Time: \(timetaken) seconds")
                //                    print("Speed: \(speed) points per second")
                //
                //                    //       timePeriod.text = timetaken.description
                //
                //                    //     /*
                //
                //
                //                case .breath:
                //                    // Start breath tracking
                //                    break
                //                default:
                //                    break
                //                }
                //            }
                
                //            switch trackTYpe {
                //            case .micor:
                //                print("mirco 0")
                //                if isPlay {
                //                    brFromMic.startRecord()
                //                }else {
                //                    brFromMic.stopRecord()
                //                }
                //            case .heart:
                //                print("1")
                //                startHeartRateQuery(isBreath: false)
                //
                //
                //            case .breath:
                //                print("2")
                //                startHeartRateQuery(isBreath: true)
                //
                //            case .directHeart:
                //
                //                if isPlay == false  {
                //
                //                    stopHRSessionOnAppleWatch()
                //                    timers?.invalidate()
                //                }else {
                //                    switch hrState {
                //                    case .running:
                //                        stopHRSessionOnAppleWatch()
                //
                //                    case .ready:
                //                        startHRSessionOnAppleWatch()
                //                    }
                //                }
                //
                //            }
            }
       // }
    }
    
    private func move(ball: UIImageView, with accelerometerData: CMAccelerometerData) {

        // MARK: - Ball speed
        let speedX = accelerometerData.acceleration.x * 20
        let speedY = accelerometerData.acceleration.y * -20
        /////
        var newX = ball.center.x + CGFloat(speedX)
        var newY = ball.center.y + CGFloat(speedY)

        if newX < ball.frame.width / 2 {
            newX = ball.frame.width / 2
        } else if newX > view.frame.width - ball.frame.width / 2 {
            newX = view.frame.width - ball.frame.width / 2
        }

        if newY < ball.frame.height / 2 {
            newY = ball.frame.height / 2
        } else if newY > view.frame.height - ball.frame.height / 2 {
            newY = view.frame.height - ball.frame.height / 2
        }

        ball.center = CGPoint(x: newX, y: newY)
    }

    private func randomPoint(for size: CGSize) -> CGPoint {

        let x = CGFloat.random(in: 0...(view.frame.width - size.width))
        let y = CGFloat.random(in: 0...(view.frame.height - size.height))
        print(x,y)
        return CGPoint(x: x, y: y)
    }
    
    private func stopHRSessionOnAppleWatch() {
        // Reset the text
        ralteLbl1.text = "0"
        
        // Send a message to the watch
        iOSSyncManager.shared.stopSession()
        timers?.invalidate()
    }
}


extension AccelerometerGame: HRServiceDelegate {
    
    func hrWasUpdated(hr: String) {
        if hrState == .running {
            
            let values =  (hr as NSString).integerValue
            hrValues.append(values)
            self.ralteLbl1.text = hr
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(5), execute: {
                self.checkAverageRate()
            })
        }
    }
    func checkAverageRate()  {
        
        let timePeriod = (timePeriod.text! as NSString).integerValue
        
        for (i,v) in hrValues.reversed().enumerated() {
            if timePeriod > 0  {
                if i == timePeriod {
                    break
                }
                averageValues += v
                print(" \(averageValues)")
            }
        }
        
        if hrValues.count < timePeriod  {
            let avgValues = averageValues / hrValues.count
            print("averageValues \(avgValues)")
            ralteLbl3.text = "\(avgValues)"
            timers =  Timer.scheduledTimer(timeInterval: 5.0, target: self, selector:#selector(changeText), userInfo: nil, repeats: true)
            averageValues = 0
        }else {
            let avgValues = averageValues / timePeriod
            print("averageValues \(avgValues)")
            ralteLbl3.text = "\(avgValues)"
            timers =  Timer.scheduledTimer(timeInterval: 5.0, target: self, selector:#selector(changeText), userInfo: nil, repeats: true)
            averageValues = 0
        }
        
    }
    
    @objc func changeText(){
        if i == hrValues.count {
            i = 0
            timers?.invalidate()
        }else {
            //            rateLbl.text = hrValues[i].description
            i += 1
            print("Total \(i)")
        }
        
    }
    @objc func fireTimer() {
        if second == 10 {
            second = 0
            isAnimationRunning = true
        } else {
            second += 1
        }
    }
    
    
    func playAnimationUsingHearRateAndAverage(){
        var loopValue = 0
        if totalPeriodValue > hrValues.count{
            loopValue = hrValues.count
        }
        else{
            loopValue = totalPeriodValue
        }
        if loopValue <= updateHeartRateLoopValue{
            playBtn.setImage(UIImage(systemName: "play.square"), for: .normal)
            isPlay = false
            updateHeartRateLoopValue = 0
            totalHeartRateValue = 0
            totalHeartRateValueCount = 0
            averageValue = 0
            self.ralteLbl1.text = "0"
            self.ralteLbl3.text = "0"
            
            self.animationForHEartRate = true
        }
       
    }
    
    func calculateAverageRate(){
       averageValue = totalHeartRateValue/totalHeartRateValueCount
        
    }
    
    
    
    func sessionStoppedOnWatch() {
        hrState = .ready
        ralteLbl1.text = "0"
        timers?.invalidate()
        
    }
    
    
    func shouldEndSession() {
        stopHRSessionOnAppleWatch()
        
    }
}

extension AccelerometerGame {
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "HealthApp", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
        
    }
    
}



//enum HRType {
//    case one
//    case two
//    case three
//    case four
//}
