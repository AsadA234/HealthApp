//
//  HealthApp.swift
//  HealthWatch WatchKit Extension
//
//  Created by Ziga Porenta on 20/10/2021.
//

import SwiftUI
import WatchKit
import HealthKit

@main
struct HealthApp: App {
    
    @WKExtensionDelegateAdaptor(ExtensionDelegate.self) var delegate
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }
        }
    }
}

class ExtensionDelegate: NSObject, WKExtensionDelegate {
    
    func applicationDidFinishLaunching() {
        WKSyncManager.shared.setup()
    }
    
    func handle(_ workoutConfiguration: HKWorkoutConfiguration) {
        WKWorkoutService.shared.startSession()
    }

}
