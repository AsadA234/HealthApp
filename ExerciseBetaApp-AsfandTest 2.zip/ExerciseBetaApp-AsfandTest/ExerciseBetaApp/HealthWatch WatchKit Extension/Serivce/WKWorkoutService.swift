//
//  WKWorkoutService.swift
//  HealthWatch WatchKit Extension
//
//  Created by Ziga Porenta on 20/10/2021.
//


import WatchKit
import Foundation
import HealthKit


class WKWorkoutService: NSObject, ObservableObject {
    
    static let shared = WKWorkoutService() 
    
    let heartRateSample = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!
    
    private let heartRateUnit = HKUnit.count().unitDivided(by: HKUnit.minute())
    private var session: HKWorkoutSession?

    private let store = HKHealthStore()

    @Published var heartRate = "--"
    @Published var state: HRSessionState = .ready
    
    
    // ****** Stored Samples and Queries
    private var hrData: [HKQuantitySample] = [HKQuantitySample]()
    
    // Timer
    private var timer: Timer?

    // ****** Query Management
    private var queries: [HKQuery] = [HKQuery]()
    private var hrAnchorValue:HKQueryAnchor?

    private var workoutStart: Date?
    private var currentHR: Int? // = 0;
    
    
    //MARK: - Functions
    
    func setupSession() {
        
        let hkWorkoutConfiguration = HKWorkoutConfiguration()
        hkWorkoutConfiguration.locationType = .indoor
        hkWorkoutConfiguration.activityType =  .mindAndBody
        
        do {
            session = try HKWorkoutSession(healthStore: store, configuration: hkWorkoutConfiguration)
        } catch {
            print("Error starting session \(error.localizedDescription)")
            session = nil
        }
        
        session?.delegate = self
        resetSession()
    }
    
    func startSession() {
        
        setupSession()
        
        session?.startActivity(with: Date())
        WKSyncManager.shared.hrSessionStarted()

        workoutStart = Date()
 
    
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            self.eachSecond()
        }
        
        queries.append(heartRateQuery(withStartDate: Date()))
        queries.forEach {
            store.execute($0)
        }
        
        // Pause session hack
        // This allows us to keep reading the heart rate but not add the exercise minutes to the activity rings
        session?.pause()
        
        state = .running
        
        
    }
    
    private func resetSession() {
        workoutStart = nil
        updateValues()
        
        heartRate = "--"
        currentHR = nil
    }
    
    
    private func eachSecond() {
        updateValues()
    }
    
    private func updateValues() {
        if let currentHR = currentHR {
            WKSyncManager.shared.sendHRToPhone(hr: currentHR)
        }
    }
    
    func endSession() {
        timer?.invalidate()
        
        session?.end()
        
        // Stop Any Queries
        for query in queries {
            store.stop(query)
        }
        queries.removeAll()
                
        state = .ready
        heartRate = "--"
        currentHR = nil
        
        
        // Notify the iPhone the session was stopped
        WKSyncManager.shared.stopSessionOnPhone()
    }
    
}

extension WKWorkoutService: HKWorkoutSessionDelegate {
    
    func workoutSession(_ workoutSession: HKWorkoutSession, didChangeTo toState: HKWorkoutSessionState, from fromState: HKWorkoutSessionState, date: Date) {
        print("Session did change state to \(toState)")
        
        DispatchQueue.main.async {
            switch toState {
                
            case .running:
                print("STARTED")
            case .ended:
                print("ENDED?")
            case .paused:
                print("CHANGED TO PAUSED")
                break
            default:
                print("Something weird happened. Not a valid state")
            }
        }
    }
    
    func workoutSession(_ workoutSession: HKWorkoutSession, didFailWithError error: Error) {
        print("🚨🚨🚨 Session failed with \(error)")
    }
    
    /// Phone call or something similar
    func workoutSession(_ workoutSession: HKWorkoutSession, didGenerate event: HKWorkoutEvent) {
        
        switch event.type {
        case .pauseOrResumeRequest:
            
            switch workoutSession.state {
                //  case .running: self.pauseSession()
            //  case .notStarted: self.startSession()
            default: break
            }
        default: break
        }
    }
}


//MARK: - Queries
extension WKWorkoutService {
    
    private func genericSamplePredicate (withStartDate start: Date) -> NSPredicate {
        let datePredicate = HKQuery.predicateForSamples(withStart: start, end: nil, options: .strictStartDate)
        let devicePredicate = HKQuery.predicateForObjects(from: [HKDevice.local()])
        return NSCompoundPredicate(andPredicateWithSubpredicates: [datePredicate, devicePredicate])
    }
    

    
    private func heartRateQuery(withStartDate start: Date) -> HKQuery {
        let predicate = genericSamplePredicate(withStartDate: start)
        
        let query: HKAnchoredObjectQuery = HKAnchoredObjectQuery(type: heartRateSample, predicate: predicate, anchor: hrAnchorValue, limit: Int(HKObjectQueryNoLimit)) { (query, samples, deletedObject, newAnchor, error) in
            
            self.hrAnchorValue = newAnchor
            self.newHRSamples(samples)
            
        }
        
        query.updateHandler = {
            (query, samples, deleteObjects, newAnchor, error) in
            
            print("UPDATING HR")
            self.hrAnchorValue = newAnchor
            self.newHRSamples(samples)
        }
        
        return query
        
    }
    

    private func newHRSamples(_ samples: [HKSample]?) {
        

        guard let samples = samples as? [HKQuantitySample], samples.count > 0 else {
            return
        }
        
        DispatchQueue.main.async {
            self.hrData += samples
            if let hr = samples.last?.quantity {
                let value = hr.doubleValue(for: self.heartRateUnit)
                
                self.currentHR = Int(value)
                self.heartRate = String(Int(value))
                
                // Send the hr to the phone
               // WKSyncManager.shared.sendHRToPhone(hr: self.currentHR)
            }
        }
    }
}
