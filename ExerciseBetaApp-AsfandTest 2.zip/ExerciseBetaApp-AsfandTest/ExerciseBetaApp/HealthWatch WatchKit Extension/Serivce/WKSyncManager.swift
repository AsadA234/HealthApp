//
//  WKSyncManager.swift
//  HealthWatch WatchKit Extension
//
//  Created by Ziga Porenta on 20/10/2021.
//


import Foundation
import WatchConnectivity

class WKSyncManager: NSObject, WCSessionDelegate, ObservableObject {
  
    static let shared = WKSyncManager()
    var session: WCSession? = nil
  
    override private init() {
        super.init()
    }
    
    func setup() {
        if WCSession.isSupported() {
            session = WCSession.default
            session?.delegate = self
            session?.activate()
        }
    }
    
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        print("⌚️ NORMAL MESSAGE - \(message)")
        
        if let _ = message[SyncConstants.stopSession.rawValue]  {
            WKWorkoutService.shared.endSession()
        }
    
    }
    
    /// Notifies the iPhone that the monitoring session was started
    func hrSessionStarted() {
        session?.sendMessage([SyncConstants.sessionStarted.rawValue: "true"], replyHandler: nil, errorHandler: nil)
    }
    
    
    func sendHRToPhone(hr: Int) {
        session?.sendMessage([SyncConstants.hr.rawValue: hr], replyHandler: nil, errorHandler: nil)
    }
    
    
    func stopSessionOnPhone() {
        session?.sendMessage([SyncConstants.stopSession.rawValue: "true"], replyHandler: nil, errorHandler: nil)
    }
    
    
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any]) {
        print("⌚️ - \(applicationContext)")

    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) {
        print("⌚️ - \(message)")
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("⌚️ - Session did activate")

     }
}

