//
//  ContentView.swift
//  HealthWatch WatchKit Extension
//
//  Created by Ziga Porenta on 20/10/2021.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var workoutService = WKWorkoutService.shared
    
    var imageName: String {
        switch workoutService.state {
        case .ready: return "play.fill"
        case .running: return "stop.fill"
        }
    }
    
    var body: some View {
        
        VStack {
            ZStack {
                Image("Group")
                Image(systemName: imageName)
                    .resizable()
                    .frame(width: 32, height: 32)
                    .aspectRatio(contentMode: .fit)
            }
            .foregroundColor(.black)
            .frame(width: 84, height: 84)
            .onTapGesture {
                tapAction()
            }
            .padding(.top, 40)
            
            Text("\(workoutService.heartRate) hr")
                .padding()
            
        }
    }
    
    private func tapAction() {
        switch workoutService.state {
        case .ready:
            workoutService.startSession()
        case .running:
            workoutService.endSession()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
                .previewDevice(.init(stringLiteral: "Apple Watch Series 6 - 44mm"))
            
            ContentView()
                .previewDevice(.init(stringLiteral: "Apple Watch Series 6 - 40mm"))
            /*
            ContentView()
                .previewDevice(.init(stringLiteral: "Apple Watch Series 3 - 38mm"))
             */
        }
    }
        
}
